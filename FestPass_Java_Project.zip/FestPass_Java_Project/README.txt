FESTPASS - JAVA CONSOLE PROJECT
================================

REQUIREMENTS
------------
- Java JDK 17 or later
- Visual Studio Code
- Java Extension Pack in VS Code (recommended)

NO WEBSITE, DATABASE, DATASET, ML MODEL OR EXTERNAL API IS USED.

HOW TO OPEN
-----------
1. Extract FestPass_Java_Project.zip.
2. Open the extracted FestPass_Java_Project folder in VS Code.
3. Open Terminal > New Terminal.
4. Make sure the terminal is in the FestPass_Java_Project folder.

COMPILE
-------
Windows:
    javac -d out src\festpass\exceptions\*.java src\festpass\model\*.java src\festpass\service\*.java src\festpass\app\*.java

Run:
    java -cp out festpass.app.FestPassApp

If using PowerShell, the same commands work in a normal VS Code terminal.

FEATURES
--------
1. Event list with LOW/OK stock status.
2. Insider and Guest bookings.
3. Undo last selected event using -1.
4. Booking validation before stock is changed.
5. Booking IDs (FST1, FST2...) and odd/even gate tokens.
6. Bill with discount, GST and final amount.
7. Search an old bill by booking ID.
8. Daily booking report and most popular event.
9. Alternative Reality Booking: compare Plan A and Plan B using budget,
   event count, schedule conflicts, remaining budget and category diversity.
10. Daily report saved to daily_report.txt when exiting.

ALTERNATIVE REALITY BOOKING
---------------------------
The event timings are sample timetable assumptions included so the program
can demonstrate schedule-conflict detection. Change startHour and endHour
in the EventPass objects if your college provides an official timetable.

The plan comparison is a simulation only. It does NOT reserve passes or
reduce stock. The suitability score is a simple rule-based score, not ML.

SCORING RULES
-------------
- Within budget: 30 points
- No schedule conflicts: 25 points
- Category diversity: up to 20 points
- Number of events: up to 15 points
- Remaining budget: up to 10 points

IMPORTANT
---------
Bookings and pass quantities are stored in arrays in memory. They reset when
the program is closed. This is intentional for the arrays-only hackathon task.
