package festpass.model;

public class ItemStack {
    private int[] eventIds = new int[20];
    private int[] quantities = new int[20];
    private int top = -1;

    public boolean isEmpty() {
        return top == -1;
    }

    public boolean isFull() {
        return top == eventIds.length - 1;
    }

    public void push(int eventId, int quantity) {
        if (!isFull()) {
            top++;
            eventIds[top] = eventId;
            quantities[top] = quantity;
        }
    }

    public int pop() {
        if (isEmpty()) {
            return -1;
        }
        int removedId = eventIds[top];
        top--;
        return removedId;
    }

    public int getEventId(int index) {
        return eventIds[index];
    }

    public int getQuantity(int index) {
        return quantities[index];
    }

    public int size() {
        return top + 1;
    }
}
