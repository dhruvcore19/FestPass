package festpass.model;

public class Guest extends Attendee {
    public Guest(String name) {
        super(name);
    }

    @Override
    public double getDiscountRate() {
        return 0.0;
    }

    @Override
    public String getType() {
        return "Guest";
    }
}
