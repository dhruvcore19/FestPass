package festpass.model;

public class EventPass {
    private int id;
    private String name;
    private String category;
    private double price;
    private int passes;
    private int startHour;
    private int endHour;

    public EventPass(int id, String name, String category, double price,
                     int passes, int startHour, int endHour) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.passes = passes;
        this.startHour = startHour;
        this.endHour = endHour;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public int getPasses() { return passes; }
    public int getStartHour() { return startHour; }
    public int getEndHour() { return endHour; }

    public void setPasses(int passes) { this.passes = passes; }

    public String getTimeSlot() {
        return String.format("%02d:00-%02d:00", startHour, endHour);
    }

    @Override
    public String toString() {
        String status = passes < 10 ? "LOW" : "OK";
        return String.format("%-5d %-22s %-12s ₹%-8.2f %-7d %s  %s",
                id, name, category, price, passes, status, getTimeSlot());
    }
}
