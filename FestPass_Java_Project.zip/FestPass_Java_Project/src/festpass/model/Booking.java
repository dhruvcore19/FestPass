package festpass.model;

public class Booking {
    private static int bookingCounter = 0;

    private String bookingId;
    private int tokenNumber;
    private Attendee attendee;
    private int[] eventIds;
    private int[] quantities;
    private int itemCount;

    public Booking(Attendee attendee, ItemStack stack, int tokenNumber) {
        bookingCounter++;
        this.bookingId = "FST" + bookingCounter;
        this.tokenNumber = tokenNumber;
        this.attendee = attendee;
        this.eventIds = new int[stack.size()];
        this.quantities = new int[stack.size()];
        this.itemCount = stack.size();

        for (int i = 0; i < itemCount; i++) {
            eventIds[i] = stack.getEventId(i);
            quantities[i] = stack.getQuantity(i);
        }
    }

    public String getBookingId() { return bookingId; }
    public int getTokenNumber() { return tokenNumber; }
    public Attendee getAttendee() { return attendee; }
    public int getItemCount() { return itemCount; }
    public int getEventId(int index) { return eventIds[index]; }
    public int getQuantity(int index) { return quantities[index]; }

    // Overloaded methods: add one item, or add an item with an explicit quantity.
    public void addItem(int eventId) {
        addItem(eventId, 1);
    }

    public void addItem(int eventId, int quantity) {
        if (itemCount < eventIds.length) {
            eventIds[itemCount] = eventId;
            quantities[itemCount] = quantity;
            itemCount++;
        }
    }

    public double calculateSubtotal(EventPass[] events) {
        return calculateSubtotal(events, 0);
    }

    // Recursive subtotal calculation.
    private double calculateSubtotal(EventPass[] events, int index) {
        if (index >= itemCount) {
            return 0;
        }

        double price = 0;
        for (EventPass event : events) {
            if (event.getId() == eventIds[index]) {
                price = event.getPrice();
                break;
            }
        }
        return price * quantities[index] + calculateSubtotal(events, index + 1);
    }

    public double calculateDiscount(EventPass[] events) {
        return calculateSubtotal(events) * attendee.getDiscountRate();
    }

    public double calculateTotal(EventPass[] events, double gstRate) {
        double discountedAmount = calculateSubtotal(events) - calculateDiscount(events);
        return discountedAmount + (discountedAmount * gstRate);
    }
}
