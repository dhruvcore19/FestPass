package festpass.model;

public interface Billable {
    double getDiscountRate();
}
