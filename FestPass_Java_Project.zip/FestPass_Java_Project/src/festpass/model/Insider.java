package festpass.model;

public class Insider extends Attendee {
    public Insider(String name) {
        super(name);
    }

    @Override
    public double getDiscountRate() {
        return 0.10;
    }

    @Override
    public String getType() {
        return "Insider";
    }
}
