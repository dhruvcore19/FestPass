package festpass.model;

public abstract class Attendee extends Person implements Billable {
    public Attendee(String name) {
        super(name);
    }

    public abstract String getType();

    @Override
    public String toString() {
        return getName() + " (" + getType() + ")";
    }
}
