package festpass.app;

import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

import festpass.model.*;
import festpass.service.FestService;
import festpass.exceptions.*;

public class FestPassApp {
    private static final double GST = 0.18;
    private static final int MAX_BOOKINGS = 200;

    private Scanner input = new Scanner(System.in);
    private EventPass[] events;
    private Booking[] bookings = new Booking[MAX_BOOKINGS];
    private int bookingCount = 0;
    private int tokenCounter = 0;
    private FestService service;

    public FestPassApp() {
        events = new EventPass[] {
            new EventPass(101, "DJ Night", "Music", 300, 100, 18, 21),
            new EventPass(102, "Coding Contest", "Technical", 100, 60, 9, 12),
            new EventPass(103, "Dance Battle", "Cultural", 150, 50, 14, 16),
            new EventPass(104, "Gaming Arena", "Technical", 200, 40, 11, 13),
            new EventPass(105, "Food Fest Coupon", "Food", 250, 80, 12, 14),
            new EventPass(106, "Celebrity Talk", "Talk", 400, 30, 16, 18)
        };
        service = new FestService(events);
    }

    public static void main(String[] args) {
        FestPassApp app = new FestPassApp();
        app.run();
    }

    private void run() {
        int choice;
        do {
            System.out.println("\\n========== FESTPASS ==========");
            System.out.println("1. View event list");
            System.out.println("2. New booking");
            System.out.println("3. View bill");
            System.out.println("4. Booking report");
            System.out.println("5. Alternative Reality Booking");
            System.out.println("6. Exit");
            choice = readInt("Enter choice: ");

            switch (choice) {
                case 1: showEvents(); break;
                case 2: newBooking(); break;
                case 3: viewBill(); break;
                case 4: showReport(); break;
                case 5: alternativeBooking(); break;
                case 6:
                    saveDailyReport();
                    System.out.println("Thank you for using FestPass!");
                    break;
                default:
                    System.out.println("Invalid menu choice. Enter 1 to 6.");
            }
        } while (choice != 6);
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = input.nextLine().trim();
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }

    private double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = input.nextLine().trim();
            try {
                double number = Double.parseDouble(value);
                if (number < 0) {
                    System.out.println("Value cannot be negative.");
                } else {
                    return number;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private void showEvents() {
        System.out.println("\\nID    EVENT                  CATEGORY     PRICE     PASSES  STATUS  TIME");
        System.out.println("--------------------------------------------------------------------------");
        for (EventPass event : events) {
            System.out.println(event);
        }
    }

    private Attendee createAttendee(String name, int type) {
        if (type == 1) {
            return new Insider(name);
        }
        return new Guest(name);
    }

    private void newBooking() {
        if (bookingCount >= MAX_BOOKINGS) {
            System.out.println("Booking storage is full.");
            return;
        }

        System.out.print("Attendee name: ");
        String name = input.nextLine().trim();
        if (name.isEmpty()) {
            System.out.println("Name cannot be empty.");
            return;
        }

        System.out.println("1. Insider (10% discount)");
        System.out.println("2. Guest (no discount)");
        int type;
        do {
            type = readInt("Attendee type: ");
            if (type != 1 && type != 2) {
                System.out.println("Enter 1 or 2.");
            }
        } while (type != 1 && type != 2);

        Attendee attendee = createAttendee(name, type);
        ItemStack stack = new ItemStack();

        System.out.println("\\nEnter event pass IDs and quantities.");
        System.out.println("Enter -1 to undo the last added event; enter 0 to finish.");

        boolean finished = false;
        while (!finished) {
            int id = readInt("Event pass ID: ");

            if (id == 0) {
                finished = true;
            } else if (id == -1) {
                int removed = stack.pop();
                if (removed == -1) {
                    System.out.println("Nothing to undo.");
                } else {
                    System.out.println("Removed the last entry for event ID " + removed + ".");
                }
            } else {
                try {
                    service.findEvent(id); // Checked exception demonstration.
                    int quantity = readInt("Quantity: ");
                    if (quantity <= 0) {
                        System.out.println("Quantity must be positive. Entry not added.");
                    } else if (stack.isFull()) {
                        System.out.println("Booking can contain at most 20 entries.");
                    } else {
                        stack.push(id, quantity);
                        System.out.println("Added to temporary booking.");
                    }
                } catch (EventPassNotFoundException e) {
                    System.out.println(e.getMessage());
                }
            }
        }

        if (stack.isEmpty()) {
            System.out.println("Booking cancelled: no event passes selected.");
            return;
        }

        // Nested try: validate first, then update stock only if every item is valid.
        try {
            try {
                service.validateBooking(stack);
                service.reduceStock(stack);
                tokenCounter++;
                Booking booking = new Booking(attendee, stack, tokenCounter);
                bookings[bookingCount] = booking;
                bookingCount++;
                System.out.println("\\nBooking successful!");
                printBill(booking);
            } catch (EventPassNotFoundException | PassesNotAvailableException e) {
                System.out.println("BOOKING REJECTED: " + e.getMessage());
                System.out.println("No passes were deducted.");
            }
        } finally {
            System.out.println("Booking check completed.");
        }
    }

    private void printBill(Booking booking) {
        double subtotal = booking.calculateSubtotal(events);
        double discount = booking.calculateDiscount(events);
        double discountedAmount = subtotal - discount;
        double gst = discountedAmount * GST;
        double total = discountedAmount + gst;
        String gate = (booking.getTokenNumber() & 1) == 1 ? "Gate A" : "Gate B";

        System.out.println("\\n========== FESTPASS BILL ==========");
        System.out.println("Booking ID : " + booking.getBookingId());
        System.out.println("Token      : " + booking.getTokenNumber());
        System.out.println("Entry      : " + gate);
        System.out.println("Name       : " + booking.getAttendee().getName());
        System.out.println("Type       : " + booking.getAttendee().getType());
        System.out.println("-----------------------------------");
        System.out.printf("%-22s %5s %10s%n", "Event", "Qty", "Amount");
        for (int i = 0; i < booking.getItemCount(); i++) {
            EventPass event = findEventWithoutException(booking.getEventId(i));
            double amount = event.getPrice() * booking.getQuantity(i);
            System.out.printf("%-22s %5d ₹%9.2f%n",
                    event.getName(), booking.getQuantity(i), amount);
        }
        System.out.println("-----------------------------------");
        System.out.printf("Subtotal                 ₹%.2f%n", subtotal);
        System.out.printf("Discount                 -₹%.2f%n", discount);
        System.out.printf("GST (18%%)                 ₹%.2f%n", gst);
        System.out.printf("FINAL TOTAL              ₹%.2f%n", total);
        System.out.println("===================================");
    }

    private EventPass findEventWithoutException(int id) {
        for (EventPass event : events) {
            if (event.getId() == id) return event;
        }
        return null;
    }

    private void viewBill() {
        System.out.print("Enter booking ID (example FST1): ");
        String id = input.nextLine().trim();
        for (int i = 0; i < bookingCount; i++) {
            if (bookings[i].getBookingId().equalsIgnoreCase(id)) {
                printBill(bookings[i]);
                return;
            }
        }
        System.out.println("No booking found with ID " + id + ".");
    }

    private void showReport() {
        System.out.println("\\n========== DAILY BOOKING REPORT ==========");
        System.out.println("Total bookings: " + bookingCount);

        double revenue = 0;
        int[] eventCounts = new int[events.length];

        for (int i = 0; i < bookingCount; i++) {
            Booking booking = bookings[i];
            revenue += booking.calculateTotal(events, GST);
            for (int j = 0; j < booking.getItemCount(); j++) {
                for (int k = 0; k < events.length; k++) {
                    if (events[k].getId() == booking.getEventId(j)) {
                        eventCounts[k] += booking.getQuantity(j);
                    }
                }
            }
        }

        System.out.printf("Total revenue: ₹%.2f%n", revenue);
        if (bookingCount == 0) {
            System.out.println("Most popular event: No bookings yet.");
        } else {
            int popularIndex = 0;
            for (int i = 1; i < eventCounts.length; i++) {
                if (eventCounts[i] > eventCounts[popularIndex]) {
                    popularIndex = i;
                }
            }
            System.out.println("Most popular event: " + events[popularIndex].getName()
                    + " (" + eventCounts[popularIndex] + " passes)");
        }
        System.out.println("==========================================");
    }

    private void alternativeBooking() {
        System.out.println("\\n===== ALTERNATIVE REALITY BOOKING =====");
        System.out.println("Compare two possible fest plans before buying passes.");
        double budget = readDouble("Enter attendee budget (₹): ");

        System.out.println("\\nAvailable event IDs:");
        showEvents();

        System.out.println("\\nPLAN A");
        int[] planA = readPlan();
        System.out.println("\\nPLAN B");
        int[] planB = readPlan();

        PlanResult resultA = evaluatePlan("Plan A", planA, budget);
        PlanResult resultB = evaluatePlan("Plan B", planB, budget);

        printPlanResult(resultA);
        printPlanResult(resultB);

        System.out.println("\\n===== COMPARISON =====");
        if (resultA.score > resultB.score) {
            System.out.println("RECOMMENDATION: PLAN A is more suitable.");
        } else if (resultB.score > resultA.score) {
            System.out.println("RECOMMENDATION: PLAN B is more suitable.");
        } else {
            System.out.println("Both plans have the same score. Choose based on your interests.");
        }
        System.out.println("This is only a simulation. No passes have been booked or deducted.");
    }

    private int[] readPlan() {
        int[] selected = new int[events.length];
        boolean[] used = new boolean[events.length];
        int count = 0;
        System.out.println("Enter event IDs. Enter 0 when the plan is complete.");

        while (true) {
            int id = readInt("Event ID: ");
            if (id == 0) break;

            int index = -1;
            for (int i = 0; i < events.length; i++) {
                if (events[i].getId() == id) index = i;
            }

            if (index == -1) {
                System.out.println("Unknown event ID. Try again.");
            } else if (used[index]) {
                System.out.println("That event is already in this plan.");
            } else if (count == selected.length) {
                System.out.println("Plan is full.");
                break;
            } else {
                selected[count] = id;
                used[index] = true;
                count++;
            }
        }

        int[] exactPlan = new int[count];
        for (int i = 0; i < count; i++) exactPlan[i] = selected[i];
        return exactPlan;
    }

    private PlanResult evaluatePlan(String name, int[] plan, double budget) {
        PlanResult result = new PlanResult(name);
        result.eventCount = plan.length;

        String[] categoryNames = {"Music", "Technical", "Cultural", "Food", "Talk"};
        boolean[] categories = new boolean[categoryNames.length];

        for (int i = 0; i < plan.length; i++) {
            EventPass current = findEventWithoutException(plan[i]);
            if (current != null) {
                result.cost += current.getPrice();
                for (int c = 0; c < categoryNames.length; c++) {
                    if (categoryNames[c].equals(current.getCategory())) {
                        categories[c] = true;
                    }
                }
            }
        }

        for (boolean categoryUsed : categories) {
            if (categoryUsed) result.categoryCount++;
        }

        for (int i = 0; i < plan.length; i++) {
            EventPass first = findEventWithoutException(plan[i]);
            for (int j = i + 1; j < plan.length; j++) {
                EventPass second = findEventWithoutException(plan[j]);
                if (first != null && second != null
                        && first.getStartHour() < second.getEndHour()
                        && second.getStartHour() < first.getEndHour()) {
                    result.conflicts++;
                }
            }
        }

        result.remainingBudget = budget - result.cost;

        // Transparent scoring rules: within budget, no clashes, variety, number of events, savings.
        if (result.remainingBudget >= 0) result.score += 30;
        if (result.conflicts == 0) result.score += 25;
        result.score += Math.min(result.categoryCount, 4) * 5;
        result.score += Math.min(result.eventCount, 3) * 5;
        if (result.remainingBudget >= 0) {
            result.score += (int) Math.min(10, (result.remainingBudget / Math.max(budget, 1)) * 10);
        }

        return result;
    }

    private void printPlanResult(PlanResult result) {
        System.out.println("\\n--- " + result.name + " ---");
        System.out.println("Events selected      : " + result.eventCount);
        System.out.printf("Total cost            : ₹%.2f%n", result.cost);
        System.out.printf("Remaining budget      : ₹%.2f%n", result.remainingBudget);
        System.out.println("Different categories  : " + result.categoryCount);
        System.out.println("Schedule conflicts    : " + result.conflicts);
        System.out.println("Suitability score     : " + result.score + "/100");
        if (result.remainingBudget < 0) {
            System.out.println("Warning: This plan exceeds the budget.");
        }
        if (result.conflicts > 0) {
            System.out.println("Warning: This plan contains overlapping event timings.");
        }
    }

    private void saveDailyReport() {
        // try-with-resources automatically closes the file.
        try (BufferedWriter writer = Files.newBufferedWriter(
                Path.of("daily_report.txt"),
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
            writer.write("FESTPASS DAILY REPORT");
            writer.newLine();
            writer.write("Total bookings: " + bookingCount);
            writer.newLine();
            double revenue = 0;
            for (int i = 0; i < bookingCount; i++) {
                revenue += bookings[i].calculateTotal(events, GST);
            }
            writer.write(String.format("Total revenue: ₹%.2f", revenue));
            writer.newLine();
            writer.write("Booking data is stored in memory while the program runs.");
            System.out.println("Daily report saved to daily_report.txt");
        } catch (IOException e) {
            System.out.println("Could not save daily report: " + e.getMessage());
        } finally {
            System.out.println("Report file operation finished.");
        }
    }

    private static class PlanResult {
        String name;
        int eventCount;
        int categoryCount;
        int conflicts;
        int score;
        double cost;
        double remainingBudget;

        PlanResult(String name) {
            this.name = name;
        }
    }
}
