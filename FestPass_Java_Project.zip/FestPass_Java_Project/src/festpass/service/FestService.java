package festpass.service;

import festpass.model.*;
import festpass.exceptions.*;

public class FestService {
    private EventPass[] events;

    public FestService(EventPass[] events) {
        this.events = events;
    }

    public EventPass findEvent(int eventId) throws EventPassNotFoundException {
        for (EventPass event : events) {
            if (event.getId() == eventId) {
                return event;
            }
        }
        throw new EventPassNotFoundException("Event pass ID " + eventId + " does not exist.");
    }

    public void validateBooking(ItemStack stack) throws EventPassNotFoundException, PassesNotAvailableException {
        // Check every requested item before changing stock.
        for (int i = 0; i < stack.size(); i++) {
            int id = stack.getEventId(i);
            int quantity = stack.getQuantity(i);
            EventPass event = findEvent(id);

            if (quantity <= 0) {
                throw new PassesNotAvailableException("Quantity must be greater than zero.");
            }

            int totalRequestedForEvent = 0;
            for (int j = 0; j < stack.size(); j++) {
                if (stack.getEventId(j) == id) {
                    totalRequestedForEvent += stack.getQuantity(j);
                }
            }

            if (totalRequestedForEvent > event.getPasses()) {
                throw new PassesNotAvailableException(
                    "Only " + event.getPasses() + " passes are available for " + event.getName()
                    + ". You requested " + totalRequestedForEvent + ".");
            }
        }
    }

    public void reduceStock(ItemStack stack) {
        for (int i = 0; i < stack.size(); i++) {
            EventPass event = null;
            for (EventPass current : events) {
                if (current.getId() == stack.getEventId(i)) {
                    event = current;
                    break;
                }
            }
            if (event != null) {
                int totalForThisId = 0;
                boolean countedEarlier = false;
                for (int j = 0; j < i; j++) {
                    if (stack.getEventId(j) == stack.getEventId(i)) {
                        countedEarlier = true;
                    }
                }
                if (!countedEarlier) {
                    for (int j = i; j < stack.size(); j++) {
                        if (stack.getEventId(j) == stack.getEventId(i)) {
                            totalForThisId += stack.getQuantity(j);
                        }
                    }
                    event.setPasses(event.getPasses() - totalForThisId);
                }
            }
        }
    }

    public EventPass[] getEvents() {
        return events;
    }
}
