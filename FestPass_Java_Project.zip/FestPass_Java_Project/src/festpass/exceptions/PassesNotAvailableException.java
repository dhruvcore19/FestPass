package festpass.exceptions;

public class PassesNotAvailableException extends Exception {
    public PassesNotAvailableException(String message) {
        super(message);
    }
}
