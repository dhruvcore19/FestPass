package festpass.exceptions;

public class EventPassNotFoundException extends Exception {
    public EventPassNotFoundException(String message) {
        super(message);
    }
}
